package projeto.expansao.activepoint

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import projeto.expansao.activepoint.models.Administrador
import projeto.expansao.activepoint.models.UsuarioComum

class BancoDeDados(context: Context) : SQLiteOpenHelper(context, "ActivePointDB", null, 3) { // Versão do banco atualizada para 3

    companion object {
        const val TABELA = "usuarios"
        const val TABELA_ADMIN = "admin"
        const val NOME = "nome"
        const val EMAIL = "email"
        const val SENHA = "senha"
        const val TELEFONE = "telefone"
        const val CPF = "cpf"
        const val CNPJ = "cnpj"
        const val NUMERO = "numero"
        const val NOME_DA_LOJA = "nome_da_loja"
        const val LOCAL = "local" // Novo campo "local"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableUsuarios = """
            CREATE TABLE $TABELA (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                $NOME TEXT,
                $EMAIL TEXT,
                $SENHA TEXT,
                $TELEFONE TEXT,
                $CPF TEXT
            )
        """.trimIndent()

        val createTableAdmin = """
            CREATE TABLE $TABELA_ADMIN (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                $NOME TEXT,
                $EMAIL TEXT,
                $SENHA TEXT,
                $NUMERO TEXT,
                $CNPJ TEXT,
                $NOME_DA_LOJA TEXT,
                $LOCAL TEXT  -- Campo "local" adicionado
            )
        """.trimIndent()

        db?.execSQL(createTableUsuarios)
        db?.execSQL(createTableAdmin)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 3) {
            try {
                db?.execSQL("ALTER TABLE $TABELA_ADMIN ADD COLUMN $LOCAL TEXT")
            } catch (e: Exception) {
                Log.e("BancoDeDados", "Erro ao atualizar a tabela $TABELA_ADMIN", e)
            }
        }
    }

    // Método para apagar todos os dados das tabelas, mantendo a estrutura
    fun limparDados() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val rowsDeletedUsuarios = db.delete(TABELA, null, null)
            val rowsDeletedAdmin = db.delete(TABELA_ADMIN, null, null)
            db.setTransactionSuccessful()
            Log.d("Cadastro", "$rowsDeletedUsuarios registros apagados da tabela $TABELA.")
            Log.d("Cadastro", "$rowsDeletedAdmin registros apagados da tabela $TABELA_ADMIN.")
        } finally {
            db.endTransaction()
        }
    }

    // Método para buscar usuários comuns (não administradores)
    fun getUsuariosComuns(): List<UsuarioComum> {
        val db = readableDatabase
        val query = "SELECT nome, cpf, numero FROM $TABELA"
        val cursor = db.rawQuery(query, null)

        val usuarios = mutableListOf<UsuarioComum>()
        try {
            while (cursor.moveToNext()) {
                // Usar os índices das colunas corretamente
                val nomeIndex = cursor.getColumnIndex(BancoDeDados.NOME)
                val cpfIndex = cursor.getColumnIndex(BancoDeDados.CPF)
                val numeroIndex = cursor.getColumnIndex(BancoDeDados.NUMERO)

                // Verificar se os índices são válidos (diferentes de -1)
                if (nomeIndex != -1 && cpfIndex != -1 && numeroIndex != -1) {
                    val nome = cursor.getString(nomeIndex)
                    val cpf = cursor.getString(cpfIndex)
                    val numero = cursor.getString(numeroIndex)

                    // Adicionar o usuário à lista
                    usuarios.add(UsuarioComum(nome, cpf, numero))
                } else {
                    // Se algum índice não for encontrado, loga um erro
                    Log.e("BancoDeDados", "Erro: Colunas não encontradas no cursor.")
                }
            }
        } catch (e: Exception) {
            Log.e("BancoDeDados", "Erro ao buscar usuários comuns", e)
        } finally {
            cursor.close()
        }

        return usuarios
    }

    // Verificar login para usuários comuns e administradores
    fun verificarLogin(email: String, senha: String): Map<String, String>? {
        val db = readableDatabase

        // Verifica se é um usuário comum
        val queryUsuarios = "SELECT * FROM $TABELA WHERE $EMAIL = ? AND $SENHA = ?"
        db.rawQuery(queryUsuarios, arrayOf(email, senha)).use { cursor ->
            if (cursor.moveToFirst()) {
                return mapOf(
                    "nome" to (cursor.getString(cursor.getColumnIndexOrThrow(NOME)) ?: "N/A"),
                    "email" to (cursor.getString(cursor.getColumnIndexOrThrow(EMAIL)) ?: "N/A"),
                    "telefone" to (cursor.getString(cursor.getColumnIndexOrThrow(TELEFONE))
                        ?: "N/A"),
                    "cpf" to (cursor.getString(cursor.getColumnIndexOrThrow(CPF)) ?: "N/A"),
                    "tipo" to "comum"
                )
            }
        }

        // Verifica se é um administrador
        val queryAdmin = "SELECT * FROM $TABELA_ADMIN WHERE $EMAIL = ? AND $SENHA = ?"
        db.rawQuery(queryAdmin, arrayOf(email, senha)).use { cursor ->
            if (cursor.moveToFirst()) {
                return mapOf(
                    "nome" to (cursor.getString(cursor.getColumnIndexOrThrow(NOME)) ?: "N/A"),
                    "email" to (cursor.getString(cursor.getColumnIndexOrThrow(EMAIL)) ?: "N/A"),
                    "numero" to (cursor.getString(cursor.getColumnIndexOrThrow(NUMERO)) ?: "N/A"),
                    "cnpj" to (cursor.getString(cursor.getColumnIndexOrThrow(CNPJ)) ?: "N/A"),
                    "nome_da_loja" to (cursor.getString(cursor.getColumnIndexOrThrow(NOME_DA_LOJA))
                        ?: "N/A"),
                    "local" to (cursor.getString(cursor.getColumnIndexOrThrow(LOCAL)) ?: "N/A"),
                    "tipo" to "admin"
                )
            }
        }
        return null
    }

    // Método para buscar dados de administradores
    // Método para buscar dados de administradores
    fun getUsuariosAdmins(): List<Administrador> {
        val db = this.readableDatabase
        val query = "SELECT nome, cpf, numero, cnpj, nome_da_loja, $LOCAL FROM $TABELA_ADMIN"
        val cursor = db.rawQuery(query, null)

        val admins = mutableListOf<Administrador>()
        while (cursor.moveToNext()) {
            // Obter índices das colunas com as constantes da classe BancoDeDados
            val nomeIndex = cursor.getColumnIndex(BancoDeDados.NOME)
            val numeroIndex = cursor.getColumnIndex(BancoDeDados.NUMERO)
            val cnpjIndex = cursor.getColumnIndex(BancoDeDados.CNPJ)
            val nomeDaLojaIndex = cursor.getColumnIndex(BancoDeDados.NOME_DA_LOJA)
            val localIndex = cursor.getColumnIndex(BancoDeDados.LOCAL)

            // Verificar se os índices são válidos
            if (nomeIndex != -1 && numeroIndex != -1 && cnpjIndex != -1 && nomeDaLojaIndex != -1 && localIndex != -1) {
                val nome = cursor.getString(nomeIndex)
                val numero = cursor.getString(numeroIndex)
                val cnpj = cursor.getString(cnpjIndex)
                val nomeDaLoja = cursor.getString(nomeDaLojaIndex)
                val local = cursor.getString(localIndex)

                // Adicionar o administrador à lista
                admins.add(Administrador(nome, numero, cnpj, nomeDaLoja, local))
            } else {
                // Caso algum índice seja inválido, loga um erro
                Log.e("BancoDeDados", "Erro: Alguma coluna não encontrada no cursor.")
            }
        }
        cursor.close()
        return admins
    }

    fun getListaAdministradores(): List<Administrador> {
        val lista = mutableListOf<Administrador>()
        val query = "SELECT * FROM ${BancoDeDados.TABELA_ADMIN}"
        val cursor = readableDatabase.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            do {
                try {
                    val nome = cursor.getString(cursor.getColumnIndexOrThrow(BancoDeDados.NOME))
                    val numero = cursor.getString(cursor.getColumnIndexOrThrow(BancoDeDados.NUMERO))
                    val cnpj = cursor.getString(cursor.getColumnIndexOrThrow(BancoDeDados.CNPJ))
                    val nomeDaLoja = cursor.getString(cursor.getColumnIndexOrThrow(BancoDeDados.NOME_DA_LOJA))
                    val local = cursor.getString(cursor.getColumnIndexOrThrow(BancoDeDados.LOCAL))

                    // Adicionando o administrador à lista
                    lista.add(Administrador(nome, numero, cnpj, nomeDaLoja, local))

                    // Verificando se os dados estão sendo lidos
                    Log.d("Database", "Administrador: $nome, $nomeDaLoja, $cnpj, $local")
                } catch (e: Exception) {
                    Log.e("DatabaseError", "Erro ao acessar dados da coluna: ${e.message}")
                }
            } while (cursor.moveToNext())
        }
        cursor.close()

        // Verificando o tamanho da lista e retorno
        Log.d("Database", "Total de administradores encontrados: ${lista.size}")
        return lista
    }


}



