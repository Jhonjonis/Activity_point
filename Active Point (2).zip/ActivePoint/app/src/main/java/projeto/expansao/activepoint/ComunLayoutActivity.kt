package projeto.expansao.activepoint

import AdminAdapter
import UsuarioAdapter
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import projeto.expansao.activepoint.databinding.ComunLayoutBinding
import recyclerUsAdapter

class ComunLayoutActivity : ComponentActivity() {

    private lateinit var binding: ComunLayoutBinding
    private lateinit var bancoDeDados: BancoDeDados
    private lateinit var recyclerViewAdapter: recyclerUsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ComunLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bancoDeDados = BancoDeDados(this)

        // Obtenção de dados de login (se necessário)
        val email = intent.getStringExtra("email") ?: ""
        val senha = intent.getStringExtra("senha") ?: ""

        try {
            // Verificação do login
            val dadosUsuario = bancoDeDados.verificarLogin(email, senha)

            if (dadosUsuario == null) {
                // Se não encontrar, exibe erro
                Log.e("LoginError", "Usuário não encontrado com o email $email")
                Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show()
            } else {
                // Se login for bem-sucedido, preenche os dados
                val nomeCompleto = dadosUsuario["nome"] ?: "Nome não encontrado"
                val cpf = dadosUsuario["cpf"] ?: "CPF não encontrado"
                val numero = dadosUsuario["telefone"] ?: "Número não encontrado"

                binding.NomeUs.text = nomeCompleto
                binding.cpfUs.text = "CPF: ${cpf}"
                binding.numeroUs.text = "NUMERO: ${numero}"
            }

            // Preencher o RecyclerView com os dados de administradores
            val administradores = bancoDeDados.getListaAdministradores()

            // Verificando se os dados foram passados corretamente para o Adapter
            Log.d("RecyclerView", "Administradores a serem exibidos: ${administradores.size}")

            recyclerViewAdapter = recyclerUsAdapter(administradores)
            binding.recyclerView.apply {
                layoutManager = LinearLayoutManager(this@ComunLayoutActivity)
                adapter = recyclerViewAdapter
            }

        } catch (e: Exception) {
            Log.e("LoginError", "Erro ao tentar fazer login: ${e.message}", e)
            Toast.makeText(this, "Erro ao fazer login. Tente novamente.", Toast.LENGTH_SHORT).show()
        }
    }
}


