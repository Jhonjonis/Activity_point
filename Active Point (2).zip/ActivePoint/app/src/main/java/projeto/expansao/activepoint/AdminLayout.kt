package projeto.expansao.activepoint

import AdminAdapter
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import projeto.expansao.activepoint.databinding.AdminLayoutBinding

class AdminLayout : ComponentActivity() {

    private lateinit var binding: AdminLayoutBinding
    private lateinit var bancoDeDados: BancoDeDados

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = AdminLayoutBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Instancia o banco de dados
        bancoDeDados = BancoDeDados(this)

        try {
            // Obtém os dados do administrador
            val administradores = bancoDeDados.getUsuariosAdmins()

            // Verifica se a lista de administradores não está vazia
            if (administradores.isNotEmpty()) {
                // Configura o RecyclerView com os administradores
                val adapterAdmin = AdminAdapter(administradores)
                binding.recyclerViewMain.layoutManager = LinearLayoutManager(this)
                binding.recyclerViewMain.adapter = adapterAdmin

                // Exibindo o nome da loja, CNPJ e número do primeiro administrador
                val admin = administradores.first()  // Pega o primeiro administrador da lista
                val nomeDaLoja = admin.nomeDaLoja ?: "Nome da loja não encontrado"
                val cnpj = admin.cnpj ?: "CNPJ não encontrado"
                val numero = admin.numero ?: "Número não encontrado"

                // Atualiza os TextViews com as informações do administrador
                binding.nome.text = nomeDaLoja
                binding.cpf.text = "CNPJ: $cnpj"
                binding.numero.text = "Número: $numero"

            } else {
                // Exibe uma mensagem caso não haja administradores
                Toast.makeText(this, "Nenhum administrador encontrado.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            // Tratamento de exceções, caso ocorra algum erro ao acessar o banco
            Toast.makeText(this, "Erro ao carregar administradores. Tente novamente.", Toast.LENGTH_SHORT).show()
        }
    }
}
