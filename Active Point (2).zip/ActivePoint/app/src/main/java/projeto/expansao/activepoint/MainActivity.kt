package projeto.expansao.activepoint

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import projeto.expansao.activepoint.databinding.LoginBinding

class MainActivity : ComponentActivity() {

    private lateinit var binding: LoginBinding
    private lateinit var bancoDeDados: BancoDeDados

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = LoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bancoDeDados = BancoDeDados(this)

        binding.btnLogin.setOnClickListener {
            // Obtém os valores inseridos pelo usuário nos campos de login
            val email = binding.edtEmail.text.toString()
            val senha = binding.edtPass.text.toString()

            // Verifica se os campos não estão vazios
            if (email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Chama o método de verificação de login
            try {
                val usuario = bancoDeDados.verificarLogin(email, senha)

                if (usuario == null) {
                    // Caso o usuário não seja encontrado (email ou senha incorretos)
                    Toast.makeText(this, "Email ou senha incorretos", Toast.LENGTH_SHORT).show()
                } else {
                    // Login bem-sucedido
                    Toast.makeText(this, "Login realizado com sucesso!", Toast.LENGTH_SHORT).show()

                    // Verifica o tipo de usuário (comum ou admin) e redireciona para a tela correta
                    val tipoUsuario = usuario["tipo"]
                    if (tipoUsuario == null) {
                        // Tipo de usuário não encontrado
                        Toast.makeText(this, "Tipo de usuário desconhecido", Toast.LENGTH_SHORT).show()
                    } else if (tipoUsuario == "admin") {
                        // Redireciona para a tela de admin
                        val intent = Intent(this, AdminLayout::class.java)
                        startActivity(intent)
                        finish() // Fecha a tela de login
                    } else if (tipoUsuario == "comum") {
                        // Redireciona para a tela de usuário comum
                        val intent = Intent(this, ComunLayoutActivity::class.java).apply {
                            // Passa o email e senha para a próxima Activity
                            putExtra("email", email)
                            putExtra("senha", senha)
                        }
                        startActivity(intent)
                        finish() // Fecha a tela de login
                    } else {
                        // Caso o tipo de usuário não seja reconhecido
                        Toast.makeText(this, "Tipo de usuário desconhecido", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                // Captura erros inesperados, como erros de banco de dados ou exceções
                Log.e("LoginError", "Erro ao tentar fazer login", e)
                Toast.makeText(this, "Erro ao fazer login. Tente novamente.", Toast.LENGTH_SHORT).show()
            }
        }


        binding.btnCadastro.setOnClickListener {
            // Redireciona para a tela de cadastro
            val intent = Intent(this, MainCadastro::class.java)
            startActivity(intent)
            finish()  // Isso finaliza a Activity atual (Login) antes de chamar o cadastro
        }
    }
}





