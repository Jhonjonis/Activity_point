import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import projeto.expansao.activepoint.R
import projeto.expansao.activepoint.models.Administrador

class recyclerUsAdapter(private val administradores: List<Administrador>) :
    RecyclerView.Adapter<recyclerUsAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgText: TextView = view.findViewById(R.id.img)
        val nomeText: TextView = view.findViewById(R.id.nome_admin)
        val cnpjText: TextView = view.findViewById(R.id.cnpj_admin)
        val localText: TextView = view.findViewById(R.id.local_admin)

        fun bind(administrador: Administrador, context: Context) {
            itemView.setOnClickListener {
                Toast.makeText(context, "Solicitação Enviada com Sucesso", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.comun_list_view, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = administradores.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val administrador = administradores[position]

        // Verifique se as informações estão sendo preenchidas corretamente
        Log.d("RecyclerView", "Preenchendo item ${position}: ${administrador.nomeDaLoja}, ${administrador.cnpj}, ${administrador.local}")

        holder.imgText.text = administrador.nome.firstOrNull()?.toString() ?: "N/A"
        holder.nomeText.text = "Loja: ${administrador.nomeDaLoja}"
        holder.cnpjText.text = "CNPJ: ${administrador.cnpj}"
        holder.localText.text = "Localização: ${administrador.local}"

        holder.bind(administrador, holder.itemView.context)
    }
}
