import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import projeto.expansao.activepoint.R
import projeto.expansao.activepoint.models.Administrador
import projeto.expansao.activepoint.models.UsuarioComum

class AdminAdapter(private val administradores: List<Administrador>) :
    RecyclerView.Adapter<AdminAdapter.ViewHolder>() {

    // ViewHolder que conecta os IDs do layout com os campos do modelo
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgText: TextView = view.findViewById(R.id.img)  // Mudança do nome para algo mais intuitivo
        val nomeText: TextView = view.findViewById(R.id.nome)  // Nome do admin
        val cpfText: TextView = view.findViewById(R.id.cpf)  // CPF
        val numeroText: TextView = view.findViewById(R.id.numero)  // Número de contato
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.user_admin_item, parent, false) // Use o nome correto do layout
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = administradores.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val administrador = administradores[position]

        // Usando a primeira letra do nome como a imagem (img)
        holder.imgText.text = administrador.nome.firstOrNull()?.toString() ?: ""  // Inicial do nome

        holder.nomeText.text = "Nome: ${administrador.nome}"
        holder.cpfText.text = "CNPJ: ${administrador.cnpj}"
        holder.numeroText.text = "Número: ${administrador.numero}"
    }
}

