package projeto.expansao.activepoint.models

data class Administrador(
    val nome: String,
    val numero: String,
    val cnpj: String,
    val nomeDaLoja: String,
    val local: String
)